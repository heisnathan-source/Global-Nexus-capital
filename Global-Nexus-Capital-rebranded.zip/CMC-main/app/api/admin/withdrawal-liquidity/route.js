import { getDb } from "@/lib/db.js";
import {
  verifySessionToken,
  ADMIN_COOKIE_NAME,
  VERIFICATION_COOKIE_NAME,
} from "@/lib/session.js";

function getSession(request) {
  const cookie = request.headers.get("cookie") || "";

  const adminMatch = cookie.match(
    new RegExp(`${ADMIN_COOKIE_NAME}=([^;]+)`)
  );

  if (adminMatch) {
    const session = verifySessionToken(adminMatch[1]);

    if (session?.role === "admin") {
      return session;
    }
  }

  const staffMatch = cookie.match(
    new RegExp(`${VERIFICATION_COOKIE_NAME}=([^;]+)`)
  );

  if (staffMatch) {
    const session = verifySessionToken(staffMatch[1]);

    if (session?.role === "verification_staff") {
      return session;
    }
  }

  return null;
}

export async function GET(request) {
  const session = getSession(request);

  if (!session) {
    return Response.json(
      { error: "Unauthorized" },
      { status: 401 }
    );
  }

  const db = getDb();

  try {
    /*
     * STAFF LIQUIDITY RULE
     *
     * A verified deposit contributes to shared withdrawal
     * liquidity ONLY when its explicit dashboard status is
     * "included".
     *
     * pending:
     *   The responsible staff member has not yet decided.
     *   It is NOT visible on the shared live dashboard and
     *   does NOT contribute to withdrawal liquidity.
     *
     * included:
     *   Visible to all staff and contributes to liquidity.
     *
     * excluded:
     *   Hidden from other staff and does NOT contribute
     *   to liquidity.
     *
     * Existing deposits were deliberately initialized as
     * "included" by the database patch.
     */

    const staffResult = await db.query(`
      SELECT
        u.id,
        u.name,
        u.staff_login,
        u.enabled AS is_active,
        COALESCE(
          u.withdrawal_liquidity_enabled,
          TRUE
        ) AS withdrawal_liquidity_enabled
      FROM users u
      WHERE u.role = 'verification_staff'
      ORDER BY u.name ASC NULLS LAST
    `);

    const rows = [];

    for (const staff of staffResult.rows) {
      /*
       * Eligible deposits:
       *
       * - verified
       * - assigned to this staff member
       * - explicitly marked "included"
       *
       * The explicit dashboard state is the source of truth.
       * We do NOT infer inclusion from the exclusion table.
       */
      const depositsResult = await db.query(
        `
          SELECT
            COALESCE(
              SUM(d.amount) FILTER (
                WHERE d.staff_dashboard_status = 'included'
              ),
              0
            ) AS eligible_deposits,

            COALESCE(
              SUM(d.amount) FILTER (
                WHERE d.staff_dashboard_status = 'excluded'
              ),
              0
            ) AS excluded_deposits,

            COALESCE(
              SUM(d.amount) FILTER (
                WHERE d.staff_dashboard_status = 'pending'
              ),
              0
            ) AS pending_deposits,

            COUNT(*) FILTER (
              WHERE d.staff_dashboard_status = 'included'
            )::int AS eligible_deposit_count,

            COUNT(*) FILTER (
              WHERE d.staff_dashboard_status = 'excluded'
            )::int AS excluded_deposit_count,

            COUNT(*) FILTER (
              WHERE d.staff_dashboard_status = 'pending'
            )::int AS pending_deposit_count

          FROM deposit_orders d
          WHERE d.assigned_staff_id = $1
            AND d.status = 'verified'
        `,
        [staff.id]
      );

      /*
       * Withdrawals actually paid by this staff member.
       *
       * IMPORTANT:
       * Use NET amount because that is the amount that leaves
       * the staff payment account for the customer withdrawal.
       *
       * The processor is the person recorded in approved_by.
       */
      const withdrawalsResult = await db.query(
        `
          SELECT
            COALESCE(
              SUM(
                COALESCE(
                  wo.net_amount,
                  wo.gross_amount - COALESCE(wo.fee_amount, 0)
                )
              ),
              0
            ) AS withdrawals_made,

            COUNT(*)::int AS withdrawal_count

          FROM withdrawal_orders wo
          LEFT JOIN LATERAL (
            SELECT r.staff_id
            FROM withdrawal_liquidity_reservations r
            WHERE r.withdrawal_order_id = wo.id
              AND r.status = 'consumed'
            ORDER BY r.consumed_at DESC NULLS LAST, r.id DESC
            LIMIT 1
          ) consumed_reservation
            ON TRUE
          WHERE wo.status = 'paid'
            AND COALESCE(
              consumed_reservation.staff_id,
              wo.approved_by
            ) = $1
        `,
        [staff.id]
      );

      /*
       * Active liquidity already reserved for withdrawals.
       *
       * This prevents the same available balance from being
       * allocated to multiple withdrawals simultaneously.
       */
      const reservationsResult = await db.query(
        `
          SELECT
            COALESCE(
              SUM(r.amount) FILTER (
                WHERE r.status = 'reserved'
              ),
              0
            ) AS reserved_amount,

            COUNT(*) FILTER (
              WHERE r.status = 'reserved'
            )::int AS reserved_count

          FROM withdrawal_liquidity_reservations r
          WHERE r.staff_id = $1
        `,
        [staff.id]
      );

      const deposits = depositsResult.rows[0];
      const withdrawals = withdrawalsResult.rows[0];
      const reservations = reservationsResult.rows[0];

      const eligibleDeposits =
        Number(deposits.eligible_deposits || 0);

      const excludedDeposits =
        Number(deposits.excluded_deposits || 0);

      const pendingDeposits =
        Number(deposits.pending_deposits || 0);

      const withdrawalsMade =
        Number(withdrawals.withdrawals_made || 0);

      const reservedAmount =
        Number(reservations.reserved_amount || 0);

      /*
       * Available withdrawal liquidity:
       *
       * INCLUDED deposits
       * - paid NET withdrawals
       * - active reservations
       *
       * Pending and excluded deposits are deliberately absent.
       */
      const availableLiquidity = Math.max(
        0,
        eligibleDeposits -
          withdrawalsMade -
          reservedAmount
      );

      rows.push({
        staffId: staff.id,
        staffName:
          staff.name || "Unnamed Staff",
        staffLogin:
          staff.staff_login || "",
        isActive:
          Boolean(staff.is_active),

        withdrawalLiquidityEnabled:
          Boolean(
            staff.withdrawal_liquidity_enabled
          ),

        eligibleDeposits,
        eligibleDepositCount:
          Number(
            deposits.eligible_deposit_count || 0
          ),

        /*
         * Pending liquidity is not available for withdrawal.
         * Main Admin receives this operational figure so the
         * admin can see why a staff member's balance has not
         * increased yet.
         */
        pendingDeposits,
        pendingDepositCount:
          Number(
            deposits.pending_deposit_count || 0
          ),

        /*
         * Excluded figures are only exposed to Main Admin
         * below.
         */
        excludedDeposits,
        excludedDepositCount:
          Number(
            deposits.excluded_deposit_count || 0
          ),

        withdrawalsMade,
        withdrawalCount:
          Number(
            withdrawals.withdrawal_count || 0
          ),

        reservedAmount,
        reservedCount:
          Number(
            reservations.reserved_count || 0
          ),

        availableLiquidity,
      });
    }

    /*
     * STAFF-FACING VIEW
     *
     * All staff can see the operational figures for each
     * staff member:
     *
     * - included deposits
     * - withdrawals made
     * - reserved amount
     * - available liquidity
     *
     * Pending amounts can also be shown as a non-liquidity
     * operational status.
     *
     * Excluded amounts/details are hidden from verification
     * staff.
     */
    const visibleRows = rows.map((row) => {
      if (session.role === "admin") {
        return row;
      }

      return {
        staffId:
          row.staffId,
        staffName:
          row.staffName,
        staffLogin:
          row.staffLogin,
        isActive:
          row.isActive,
        withdrawalLiquidityEnabled:
          row.withdrawalLiquidityEnabled,

        eligibleDeposits:
          row.eligibleDeposits,

        eligibleDepositCount:
          row.eligibleDepositCount,

        pendingDeposits:
          row.pendingDeposits,

        pendingDepositCount:
          row.pendingDepositCount,

        withdrawalsMade:
          row.withdrawalsMade,

        withdrawalCount:
          row.withdrawalCount,

        reservedAmount:
          row.reservedAmount,

        reservedCount:
          row.reservedCount,

        availableLiquidity:
          row.availableLiquidity,
      };
    });

    const totals = rows.reduce(
      (acc, row) => {
        acc.eligibleDeposits +=
          row.eligibleDeposits;

        acc.pendingDeposits +=
          row.pendingDeposits;

        acc.excludedDeposits +=
          row.excludedDeposits;

        acc.withdrawalsMade +=
          row.withdrawalsMade;

        acc.reservedAmount +=
          row.reservedAmount;

        acc.availableLiquidity +=
          row.availableLiquidity;

        acc.eligibleDepositCount +=
          row.eligibleDepositCount;

        acc.pendingDepositCount +=
          row.pendingDepositCount;

        acc.excludedDepositCount +=
          row.excludedDepositCount;

        acc.withdrawalCount +=
          row.withdrawalCount;

        acc.reservedCount +=
          row.reservedCount;

        return acc;
      },
      {
        eligibleDeposits: 0,
        pendingDeposits: 0,
        excludedDeposits: 0,
        withdrawalsMade: 0,
        reservedAmount: 0,
        availableLiquidity: 0,

        eligibleDepositCount: 0,
        pendingDepositCount: 0,
        excludedDepositCount: 0,
        withdrawalCount: 0,
        reservedCount: 0,
      }
    );

    /*
     * Verification staff must never receive excluded
     * financial totals.
     */
    const responseTotals =
      session.role === "admin"
        ? totals
        : {
            eligibleDeposits:
              totals.eligibleDeposits,

            pendingDeposits:
              totals.pendingDeposits,

            withdrawalsMade:
              totals.withdrawalsMade,

            reservedAmount:
              totals.reservedAmount,

            availableLiquidity:
              totals.availableLiquidity,

            eligibleDepositCount:
              totals.eligibleDepositCount,

            pendingDepositCount:
              totals.pendingDepositCount,

            withdrawalCount:
              totals.withdrawalCount,

            reservedCount:
              totals.reservedCount,
          };

    return Response.json({
      success: true,

      generatedAt:
        new Date().toISOString(),

      calculation: {
        eligibleDeposits:
          "Verified deposits assigned to staff and explicitly marked included.",

        pendingDeposits:
          "Verified deposits awaiting the responsible staff member's dashboard decision. They do not count toward liquidity.",

        excludedDeposits:
          "Verified deposits explicitly excluded from the shared staff dashboard. They do not count toward liquidity.",

        withdrawalsMade:
          "Paid withdrawals recorded against the staff member, using the net withdrawal amount.",

        reservedAmount:
          "Withdrawal liquidity already reserved for processing.",

        availableLiquidity:
          "Included deposits minus paid net withdrawals and active reservations.",
      },

      staff:
        visibleRows,

      totals:
        responseTotals,

      currentUser: {
        id:
          session.userId,
        role:
          session.role,
      },
    });
  } catch (error) {
    console.error(
      "GET /api/admin/withdrawal-liquidity failed:",
      error
    );

    return Response.json(
      {
        error:
          "Unable to calculate withdrawal liquidity.",
      },
      { status: 500 }
    );
  } finally {
  }
}
