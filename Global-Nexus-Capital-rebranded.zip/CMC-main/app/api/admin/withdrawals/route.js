import { getDb } from "@/lib/db.js";
import {
  verifySessionToken,
  ADMIN_COOKIE_NAME,
  VERIFICATION_COOKIE_NAME,
} from "@/lib/session.js";

const CLAIM_TIMEOUT_MINUTES = 15;

function getSession(request) {
  const cookie = request.headers.get("cookie") || "";

  const adminMatch = cookie.match(
    new RegExp(`${ADMIN_COOKIE_NAME}=([^;]+)`)
  );

  if (adminMatch) {
    const admin = verifySessionToken(adminMatch[1]);

    if (admin && admin.role === "admin") {
      return admin;
    }
  }

  const staffMatch = cookie.match(
    new RegExp(`${VERIFICATION_COOKIE_NAME}=([^;]+)`)
  );

  if (staffMatch) {
    const staff = verifySessionToken(staffMatch[1]);

    if (
      staff &&
      staff.role === "verification_staff"
    ) {
      return staff;
    }
  }

  return null;
}

function isAdmin(session) {
  return session?.role === "admin";
}

function isStaff(session) {
  return session?.role === "verification_staff";
}

function safeError(error) {
  const message = String(error?.message || "");

  const allowed = new Set([
    "Withdrawal order not found.",
    "Withdrawal is no longer pending.",
    "Withdrawal is no longer processing.",
    "This withdrawal is already being processed by another staff member.",
    "You are not assigned to this withdrawal.",
    "Claim has expired and the withdrawal was returned to the pending queue.",
    "Matching withdrawal transaction not found.",
    "Matching withdrawal transaction is not pending.",
    "User wallet not found.",
    "Invalid withdrawal amount.",
    "Reserved balance is insufficient for this withdrawal.",
    "Payment reference is required.",
    "Payment reference is too long.",
    "Rejection reason is required.",
    "Rejection reason is too long.",
    "Only verification staff can claim withdrawals.",
    "Only the assigned verification staff can update this withdrawal.",
    "Only an administrator can release a claim.",
    "Only an administrator can reassign a withdrawal.",
    "Only an administrator can perform this action.",
    "Verification staff cannot approve withdrawals directly.",
    "Verification staff cannot release or reassign withdrawals.",
    "Verification staff cannot finalize this withdrawal.",
    "Invalid withdrawal action.",
    "Verification staff account not found.",
    "Selected verification staff account is disabled.",
    "This withdrawal has already been allocated.",
    "No single staff member has enough eligible liquidity for this withdrawal.",
    "Staff liquidity is disabled for this withdrawal allocation.",
    "Withdrawal allocation failed.",
    "Withdrawal liquidity reservation not found.",
  ]);

  return allowed.has(message)
    ? message
    : "Unable to process withdrawal.";
}

async function audit(
  client,
  {
    actorId,
    action,
    entityId,
    previousValue,
    newValue,
    reason = null,
  }
) {
  await client.query(
    `
      INSERT INTO audit_logs (
        admin_user_id,
        action,
        entity_type,
        entity_id,
        previous_value,
        new_value,
        reason
      )
      VALUES (
        $1,
        $2,
        'withdrawal',
        $3,
        $4::jsonb,
        $5::jsonb,
        $6
      )
    `,
    [
      actorId,
      action,
      entityId,
      JSON.stringify(previousValue ?? null),
      JSON.stringify(newValue ?? null),
      reason,
    ]
  );
}

/*
 * Calculate the staff member's real eligible liquidity.
 *
 * eligible deposits
 * - paid withdrawals funded by that staff member
 * - active reservations
 *
 * Excluded deposits are deliberately NOT counted.
 */
async function getStaffLiquidity(client, staffId) {
  const deposits = await client.query(
    `
      SELECT
        COALESCE(
          SUM(d.amount),
          0
        ) AS eligible_deposits
      FROM deposit_orders d
      WHERE d.assigned_staff_id = $1
        AND d.status = 'verified'
        AND d.staff_dashboard_status = 'included'
    `,
    [staffId]
  );

  const paidWithdrawals = await client.query(
    `
      SELECT
        COALESCE(
          SUM(
            COALESCE(
              wo.net_amount,
              wo.gross_amount - COALESCE(wo.fee_amount, 0)
            )
          ),
          0
        ) AS paid_withdrawals
      FROM withdrawal_orders wo
      WHERE wo.approved_by = $1
        AND wo.status = 'paid'
    `,
    [staffId]
  );

  const reservations = await client.query(
    `
      SELECT
        COALESCE(
          SUM(r.amount),
          0
        ) AS reserved_amount
      FROM withdrawal_liquidity_reservations r
      WHERE r.staff_id = $1
        AND r.status = 'reserved'
    `,
    [staffId]
  );

  const eligibleDeposits = Number(
    deposits.rows[0]?.eligible_deposits || 0
  );

  const paid = Number(
    paidWithdrawals.rows[0]?.paid_withdrawals || 0
  );

  const reserved = Number(
    reservations.rows[0]?.reserved_amount || 0
  );

  return {
    eligibleDeposits,
    paidWithdrawals: paid,
    reservedAmount: reserved,
    availableLiquidity: Math.max(
      0,
      eligibleDeposits - paid - reserved
    ),
  };
}

/*
 * Allocate ONE withdrawal to ONE staff member.
 *
 * We deliberately do not split a withdrawal between staff.
 *
 * The staff member must have enough liquidity for the
 * customer's net payout.
 */
async function allocateWithdrawal(
  client,
  {
    order,
    actorId,
    requestedStaffId = null,
    automated = false,
  }
) {
  if (
    order.status !== "pending"
  ) {
    throw new Error(
      "Withdrawal is no longer pending."
    );
  }

  const existing = await client.query(
    `
      SELECT
        id,
        staff_id,
        amount,
        status
      FROM withdrawal_liquidity_reservations
      WHERE withdrawal_order_id = $1
        AND status IN ('reserved', 'consumed')
      FOR UPDATE
    `,
    [order.id]
  );

  if (existing.rowCount) {
    throw new Error(
      "This withdrawal has already been allocated."
    );
  }

  /*
   * Use net_amount because this is the amount that must
   * actually be funded from the staff payment account.
   */
  const requiredAmount = Number(
    order.net_amount || 0
  );

  if (
    !Number.isFinite(requiredAmount) ||
    requiredAmount <= 0
  ) {
    throw new Error(
      "Invalid withdrawal amount."
    );
  }

  let staffResult;

  if (requestedStaffId) {
    staffResult = await client.query(
      `
        SELECT
          id,
          name,
          staff_login,
          enabled,
          COALESCE(
            withdrawal_liquidity_enabled,
            TRUE
          ) AS withdrawal_liquidity_enabled
        FROM users
        WHERE id = $1
          AND role = 'verification_staff'
        FOR UPDATE
      `,
      [requestedStaffId]
    );

    if (!staffResult.rowCount) {
      throw new Error(
        "Verification staff account not found."
      );
    }

    if (!staffResult.rows[0].enabled) {
      throw new Error(
        "Selected verification staff account is disabled."
      );
    }

    if (
      !staffResult.rows[0]
        .withdrawal_liquidity_enabled
    ) {
      throw new Error(
        "Staff liquidity is disabled for this withdrawal allocation."
      );
    }
  } else {
    /*
     * Lock all eligible staff rows in a deterministic order.
     * This keeps concurrent allocation attempts from
     * selecting the same liquidity.
     */
    staffResult = await client.query(`
      SELECT
        id,
        name,
        staff_login,
        enabled,
        COALESCE(
          withdrawal_liquidity_enabled,
          TRUE
        ) AS withdrawal_liquidity_enabled
      FROM users
      WHERE role = 'verification_staff'
        AND enabled = TRUE
        AND COALESCE(
          withdrawal_liquidity_enabled,
          TRUE
        ) = TRUE
      ORDER BY id ASC
      FOR UPDATE
    `);
  }

  let selectedStaff = null;
  let selectedLiquidity = null;

  for (const staff of staffResult.rows) {
    if (!staff.enabled) {
      continue;
    }

    if (
      !staff.withdrawal_liquidity_enabled
    ) {
      continue;
    }

    const liquidity =
      await getStaffLiquidity(
        client,
        staff.id
      );

    if (
      liquidity.availableLiquidity >=
      requiredAmount
    ) {
      selectedStaff = staff;
      selectedLiquidity = liquidity;
      break;
    }

    /*
     * If a specifically requested staff member was
     * selected, do not silently choose somebody else.
     */
    if (
      requestedStaffId &&
      String(staff.id) ===
        String(requestedStaffId)
    ) {
      selectedStaff = staff;
      selectedLiquidity = liquidity;
      break;
    }
  }

  if (!selectedStaff) {
    throw new Error(
      "No single staff member has enough eligible liquidity for this withdrawal."
    );
  }

  if (
    selectedLiquidity.availableLiquidity <
    requiredAmount
  ) {
    throw new Error(
      "No single staff member has enough eligible liquidity for this withdrawal."
    );
  }

  /*
   * Reserve the staff liquidity and mark the withdrawal
   * as processing for that staff member in the same
   * database transaction.
   */
  const reservation = await client.query(
    `
      INSERT INTO withdrawal_liquidity_reservations (
        staff_id,
        withdrawal_order_id,
        amount,
        status,
        created_at,
        created_by
      )
      VALUES (
        $1,
        $2,
        $3,
        'reserved',
        NOW(),
        $4
      )
      RETURNING *
    `,
    [
      selectedStaff.id,
      order.id,
      requiredAmount,
      actorId,
    ]
  );

  const updated = await client.query(
    `
      UPDATE withdrawal_orders
      SET
        status = 'processing',
        claimed_by = $2,
        claimed_at = NOW(),
        claim_activity_at = NOW()
      WHERE id = $1
        AND status = 'pending'
        AND claimed_by IS NULL
      RETURNING *
    `,
    [
      order.id,
      selectedStaff.id,
    ]
  );

  if (updated.rowCount !== 1) {
    throw new Error(
      "Withdrawal allocation failed."
    );
  }

  await audit(client, {
    actorId,
    action: "withdrawal_liquidity_allocated",
    entityId: order.id,
    previousValue: {
      status: order.status,
      claimed_by: order.claimed_by,
    },
    newValue: {
      status: "processing",
      claimed_by: selectedStaff.id,
      liquidity_reservation_id:
        reservation.rows[0].id,
      reservation_amount:
        requiredAmount,
      staff_eligible_liquidity:
        selectedLiquidity.availableLiquidity,
      automated,
    },
    reason: automated
      ? "Withdrawal automatically allocated from eligible staff liquidity."
      : "Withdrawal manually allocated from eligible staff liquidity.",
  });

  return {
    order: updated.rows[0],
    reservation: reservation.rows[0],
    staff: selectedStaff,
    liquidity: selectedLiquidity,
  };
}

async function releaseReservation(
  client,
  withdrawalOrderId,
  actorId,
  reason
) {
  const result = await client.query(
    `
      SELECT
        id,
        staff_id,
        amount,
        status
      FROM withdrawal_liquidity_reservations
      WHERE withdrawal_order_id = $1
        AND status = 'reserved'
      FOR UPDATE
    `,
    [withdrawalOrderId]
  );

  if (!result.rowCount) {
    return null;
  }

  const reservation = result.rows[0];

  await client.query(
    `
      UPDATE withdrawal_liquidity_reservations
      SET
        status = 'released',
        released_at = NOW()
      WHERE id = $1
        AND status = 'reserved'
    `,
    [reservation.id]
  );

  await audit(client, {
    actorId,
    action: "withdrawal_liquidity_released",
    entityId: withdrawalOrderId,
    previousValue: {
      reservation_id: reservation.id,
      staff_id: reservation.staff_id,
      amount: reservation.amount,
      status: "reserved",
    },
    newValue: {
      reservation_id: reservation.id,
      staff_id: reservation.staff_id,
      amount: reservation.amount,
      status: "released",
    },
    reason,
  });

  return reservation;
}

async function consumeReservation(
  client,
  withdrawalOrderId,
  actorId
) {
  const result = await client.query(
    `
      SELECT
        id,
        staff_id,
        amount,
        status
      FROM withdrawal_liquidity_reservations
      WHERE withdrawal_order_id = $1
        AND status = 'reserved'
      FOR UPDATE
    `,
    [withdrawalOrderId]
  );

  if (!result.rowCount) {
    throw new Error(
      "Withdrawal liquidity reservation not found."
    );
  }

  const reservation = result.rows[0];

  await client.query(
    `
      UPDATE withdrawal_liquidity_reservations
      SET
        status = 'consumed',
        consumed_at = NOW()
      WHERE id = $1
        AND status = 'reserved'
    `,
    [reservation.id]
  );

  await audit(client, {
    actorId,
    action: "withdrawal_liquidity_consumed",
    entityId: withdrawalOrderId,
    previousValue: {
      reservation_id: reservation.id,
      staff_id: reservation.staff_id,
      amount: reservation.amount,
      status: "reserved",
    },
    newValue: {
      reservation_id: reservation.id,
      staff_id: reservation.staff_id,
      amount: reservation.amount,
      status: "consumed",
    },
    reason:
      "Withdrawal payment completed.",
  });

  return reservation;
}

async function expireInactiveClaims(client) {
  const expired = await client.query(
    `
      SELECT
        wo.id,
        wo.claimed_by,
        wo.claimed_at,
        wo.claim_activity_at
      FROM withdrawal_orders wo
      WHERE wo.status = 'processing'
        AND wo.claim_activity_at IS NOT NULL
        AND wo.claim_activity_at <
          NOW() - ($1 * INTERVAL '1 minute')
      FOR UPDATE SKIP LOCKED
    `,
    [CLAIM_TIMEOUT_MINUTES]
  );

  for (const row of expired.rows) {
    await releaseReservation(
      client,
      row.id,
      row.claimed_by,
      `Verification claim expired after ${CLAIM_TIMEOUT_MINUTES} minutes without processing activity.`
    );

    await client.query(
      `
        UPDATE withdrawal_orders
        SET
          status = 'pending',
          claimed_by = NULL,
          claimed_at = NULL,
          claim_activity_at = NULL
        WHERE id = $1
          AND status = 'processing'
          AND claimed_by = $2
      `,
      [row.id, row.claimed_by]
    );

    if (row.claimed_by) {
      await audit(client, {
        actorId: row.claimed_by,
        action: "withdrawal_claim_timeout",
        entityId: row.id,
        previousValue: {
          status: "processing",
          claimed_by: row.claimed_by,
          claimed_at: row.claimed_at,
          claim_activity_at:
            row.claim_activity_at,
        },
        newValue: {
          status: "pending",
          claimed_by: null,
          claimed_at: null,
          claim_activity_at: null,
          automated: true,
        },
        reason: `Verification claim expired after ${CLAIM_TIMEOUT_MINUTES} minutes without processing activity.`,
      });
    }
  }

  return expired.rowCount;
}

async function releaseExpiredSingleClaim(
  client,
  order
) {
  if (
    order.status !== "processing" ||
    !order.claim_activity_at
  ) {
    return false;
  }

  const activityTime =
    new Date(
      order.claim_activity_at
    ).getTime();

  const expired =
    Number.isFinite(activityTime) &&
    Date.now() - activityTime >
      CLAIM_TIMEOUT_MINUTES *
        60 *
        1000;

  if (!expired) {
    return false;
  }

  await releaseReservation(
    client,
    order.id,
    order.claimed_by,
    `Verification claim expired after ${CLAIM_TIMEOUT_MINUTES} minutes without processing activity.`
  );

  await client.query(
    `
      UPDATE withdrawal_orders
      SET
        status = 'pending',
        claimed_by = NULL,
        claimed_at = NULL,
        claim_activity_at = NULL
      WHERE id = $1
        AND status = 'processing'
        AND claimed_by = $2
    `,
    [
      order.id,
      order.claimed_by,
    ]
  );

  if (order.claimed_by) {
    await audit(client, {
      actorId: order.claimed_by,
      action: "withdrawal_claim_timeout",
      entityId: order.id,
      previousValue: {
        status: order.status,
        claimed_by: order.claimed_by,
        claimed_at: order.claimed_at,
        claim_activity_at:
          order.claim_activity_at,
      },
      newValue: {
        status: "pending",
        claimed_by: null,
        claimed_at: null,
        claim_activity_at: null,
        automated: true,
      },
      reason: `Verification claim expired after ${CLAIM_TIMEOUT_MINUTES} minutes without processing activity.`,
    });
  }

  return true;
}

async function getCounts(client) {
  const result = await client.query(`
    SELECT
      COUNT(*) FILTER (
        WHERE status = 'pending'
      )::int AS pending,

      COUNT(*) FILTER (
        WHERE status = 'processing'
      )::int AS processing,

      COUNT(*) FILTER (
        WHERE status = 'paid'
        AND processed_at >= CURRENT_DATE
      )::int AS completed_today,

      COUNT(*) FILTER (
        WHERE status = 'rejected'
        AND processed_at >= CURRENT_DATE
      )::int AS rejected_today
    FROM withdrawal_orders
  `);

  return result.rows[0] || {
    pending: 0,
    processing: 0,
    completed_today: 0,
    rejected_today: 0,
  };
}

async function getReservationMap(
  client
) {
  const result = await client.query(`
    SELECT
      r.withdrawal_order_id,
      r.id AS reservation_id,
      r.staff_id,
      r.amount,
      r.status,
      r.created_at,
      r.consumed_at,
      r.released_at,

      u.name AS staff_name,
      u.staff_login

    FROM withdrawal_liquidity_reservations r

    LEFT JOIN users u
      ON u.id = r.staff_id

    WHERE r.status IN (
      'reserved',
      'consumed'
    )
  `);

  return new Map(
    result.rows.map((row) => [
      String(row.withdrawal_order_id),
      row,
    ])
  );
}

export async function GET(request) {
  const session = getSession(request);

  if (!session) {
    return Response.json(
      { error: "Unauthorized" },
      { status: 401 }
    );
  }

  const db = getDb();
  const client = await db.connect();

  try {
    await client.query("BEGIN");

    await expireInactiveClaims(client);

    const result = await client.query(`
      SELECT
        wo.id,
        wo.user_id,
        wo.gross_amount,
        wo.fee_amount,
        wo.net_amount,
        wo.status,
        wo.scheduled_at,
        wo.created_at,
        wo.processed_at,
        wo.rejection_reason,

        wo.claimed_by,
        wo.claimed_at,
        wo.claim_activity_at,
        wo.payment_reference,
        wo.payment_sent_at,

        wo.approved_by,

        u.phone,
        u.name,

        claimant.name AS claimant_name,
        claimant.staff_login AS claimant_login,

        processor.name AS processor_name,
        processor.staff_login AS processor_login

      FROM withdrawal_orders wo

      LEFT JOIN users u
        ON u.id = wo.user_id

      LEFT JOIN users claimant
        ON claimant.id = wo.claimed_by

      LEFT JOIN users processor
        ON processor.id = wo.approved_by

      ORDER BY
        CASE
          WHEN wo.status = 'pending' THEN 0
          WHEN wo.status = 'processing' THEN 1
          WHEN wo.status = 'paid' THEN 2
          WHEN wo.status = 'rejected' THEN 3
          ELSE 4
        END,
        wo.created_at DESC
    `);

    const counts =
      await getCounts(client);

    const reservationMap =
      await getReservationMap(client);

    const staffResult = isAdmin(session)
      ? await client.query(`
          SELECT
            id,
            name,
            staff_login,
            role,
            enabled AS is_active,
            COALESCE(
              withdrawal_liquidity_enabled,
              TRUE
            ) AS withdrawal_liquidity_enabled
          FROM users
          WHERE role = 'verification_staff'
          ORDER BY name ASC NULLS LAST
        `)
      : {
          rows: [],
        };

    await client.query("COMMIT");

    const now = Date.now();

    const orders = result.rows.map(
      (row) => {
        const activityTime =
          row.claim_activity_at
            ? new Date(
                row.claim_activity_at
              ).getTime()
            : null;

        const remainingSeconds =
          row.status === "processing" &&
          Number.isFinite(activityTime)
            ? Math.max(
                0,
                CLAIM_TIMEOUT_MINUTES *
                  60 -
                  Math.floor(
                    (now - activityTime) /
                      1000
                  )
              )
            : null;

        const reservation =
          reservationMap.get(
            String(row.id)
          );

        return {
          ...row,

          claimed_by_me:
            String(
              row.claimed_by || ""
            ) ===
            String(
              session.userId || ""
            ),

          claim_timeout_minutes:
            CLAIM_TIMEOUT_MINUTES,

          claim_remaining_seconds:
            remainingSeconds,

          claim_expired:
            remainingSeconds !== null &&
            remainingSeconds <= 0,

          liquidity_allocated:
            Boolean(reservation),

          liquidity_reservation_id:
            reservation?.reservation_id ||
            null,

          liquidity_staff_id:
            reservation?.staff_id ||
            null,

          liquidity_staff_name:
            reservation?.staff_name ||
            null,

          liquidity_staff_login:
            reservation?.staff_login ||
            null,

          liquidity_reserved_amount:
            reservation
              ? Number(
                  reservation.amount || 0
                )
              : 0,

          liquidity_reservation_status:
            reservation?.status ||
            null,
        };
      }
    );

    return Response.json({
      orders,
      counts,

      claimTimeoutMinutes:
        CLAIM_TIMEOUT_MINUTES,

      staff:
        staffResult.rows,

      currentUser: {
        id: session.userId,
        role: session.role,
      },
    });
  } catch (error) {
    try {
      await client.query("ROLLBACK");
    } catch {}

    console.error(
      "GET /api/admin/withdrawals failed:",
      error
    );

    return Response.json(
      {
        error:
          "Unable to load withdrawal orders.",
      },
      { status: 500 }
    );
  } finally {
    client.release();
  }
}

export async function POST(request) {
  const session = getSession(request);

  if (!session) {
    return Response.json(
      { error: "Unauthorized" },
      { status: 401 }
    );
  }

  let body;

  try {
    body = await request.json();
  } catch {
    return Response.json(
      {
        error:
          "Invalid request body.",
      },
      { status: 400 }
    );
  }

  const orderId = body?.orderId;

  const action = String(
    body?.action || ""
  )
    .trim()
    .toLowerCase();

  const reason = String(
    body?.reason || ""
  ).trim();

  const paymentReference =
    String(
      body?.paymentReference || ""
    ).trim();

  const assignedStaffId =
    body?.staffId ||
    body?.assignedTo ||
    null;

  if (!orderId || !action) {
    return Response.json(
      {
        error:
          "Valid order and action are required.",
      },
      { status: 400 }
    );
  }

  const allowedActions =
    new Set([
      "claim",
      "touch",
      "pay",
      "reject",
      "release",
      "reassign",
      "approve",
      "allocate",
    ]);

  if (!allowedActions.has(action)) {
    return Response.json(
      {
        error:
          "Invalid withdrawal action.",
      },
      { status: 400 }
    );
  }

  /*
   * Liquidity allocation is an administrative
   * distribution operation.
   *
   * Verification staff never decide which staff
   * member receives another withdrawal.
   */
  if (
    action === "allocate" &&
    !isAdmin(session)
  ) {
    return Response.json(
      {
        error:
          "Only an administrator can perform this action.",
      },
      { status: 403 }
    );
  }

  const db = getDb();
  const client = await db.connect();

  try {
    await client.query("BEGIN");

    await expireInactiveClaims(client);

    const result = await client.query(
      `
        SELECT *
        FROM withdrawal_orders
        WHERE id = $1
        FOR UPDATE
      `,
      [orderId]
    );

    if (!result.rowCount) {
      throw new Error(
        "Withdrawal order not found."
      );
    }

    let order = result.rows[0];

    if (
      await releaseExpiredSingleClaim(
        client,
        order
      )
    ) {
      if (action !== "claim") {
        throw new Error(
          "Claim has expired and the withdrawal was returned to the pending queue."
        );
      }

      const refreshed =
        await client.query(
          `
            SELECT *
            FROM withdrawal_orders
            WHERE id = $1
            FOR UPDATE
          `,
          [orderId]
        );

      order = refreshed.rows[0];
    }

    /*
     * ========================================================
     * AUTOMATIC / MANUAL LIQUIDITY ALLOCATION
     * ========================================================
     */
    if (action === "allocate") {
      if (!isAdmin(session)) {
        throw new Error(
          "Only an administrator can perform this action."
        );
      }

      if (order.status !== "pending") {
        throw new Error(
          "Withdrawal is no longer pending."
        );
      }

      const allocation =
        await allocateWithdrawal(
          client,
          {
            order,
            actorId:
              session.userId,
            requestedStaffId:
              assignedStaffId,
            automated: !assignedStaffId,
          }
        );

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "allocate",

        order:
          allocation.order,

        allocation: {
          staffId:
            allocation.staff.id,

          staffName:
            allocation.staff.name,

          staffLogin:
            allocation.staff.staff_login,

          reservedAmount:
            allocation.reservation
              .amount,

          eligibleLiquidityBefore:
            allocation.liquidity
              .availableLiquidity,
        },
      });
    }

    /*
     * ========================================================
     * CLAIM
     * ========================================================
     */
    if (action === "claim") {
      if (!isStaff(session)) {
        throw new Error(
          "Only verification staff can claim withdrawals."
        );
      }

      /*
       * If Admin has already allocated the withdrawal,
       * only the allocated staff member can process it.
       */
      if (
        order.status ===
          "processing" &&
        order.claimed_by &&
        String(
          order.claimed_by
        ) !==
          String(
            session.userId
          )
      ) {
        throw new Error(
          "This withdrawal is already being processed by another staff member."
        );
      }

      if (
        order.status !== "pending"
      ) {
        throw new Error(
          "Withdrawal is no longer pending."
        );
      }

      /*
       * Staff claim now performs liquidity allocation
       * atomically when a withdrawal has not already been
       * allocated.
       */
      const allocation =
        await allocateWithdrawal(
          client,
          {
            order,
            actorId:
              session.userId,
            requestedStaffId:
              session.userId,
            automated: false,
          }
        );

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "claim",

        order:
          allocation.order,

        allocation: {
          staffId:
            allocation.staff.id,

          staffName:
            allocation.staff.name,

          reservedAmount:
            allocation.reservation
              .amount,
        },
      });
    }

    /*
     * ========================================================
     * TOUCH / HEARTBEAT
     * ========================================================
     */
    if (action === "touch") {
      if (!isStaff(session)) {
        throw new Error(
          "Only verification staff can claim withdrawals."
        );
      }

      if (
        order.status !==
        "processing"
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      if (
        String(
          order.claimed_by
        ) !==
        String(
          session.userId
        )
      ) {
        throw new Error(
          "You are not assigned to this withdrawal."
        );
      }

      const touched =
        await client.query(
          `
            UPDATE withdrawal_orders
            SET
              claim_activity_at = NOW()
            WHERE id = $1
              AND status = 'processing'
              AND claimed_by = $2
            RETURNING claim_activity_at
          `,
          [
            orderId,
            session.userId,
          ]
        );

      if (
        touched.rowCount !== 1
      ) {
        throw new Error(
          "You are not assigned to this withdrawal."
        );
      }

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "touch",

        claim_activity_at:
          touched.rows[0]
            .claim_activity_at,
      });
    }

    /*
     * ========================================================
     * RELEASE
     * ========================================================
     */
    if (action === "release") {
      if (!isAdmin(session)) {
        throw new Error(
          "Only an administrator can release a claim."
        );
      }

      if (
        order.status !==
        "processing"
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      await releaseReservation(
        client,
        orderId,
        session.userId,
        reason ||
          "Administrator manually released the withdrawal claim."
      );

      const released =
        await client.query(
          `
            UPDATE withdrawal_orders
            SET
              status = 'pending',
              claimed_by = NULL,
              claimed_at = NULL,
              claim_activity_at = NULL
            WHERE id = $1
              AND status = 'processing'
            RETURNING *
          `,
          [orderId]
        );

      if (
        released.rowCount !== 1
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      await audit(client, {
        actorId:
          session.userId,

        action:
          "withdrawal_claim_release",

        entityId:
          orderId,

        previousValue: {
          status:
            order.status,

          claimed_by:
            order.claimed_by,

          claimed_at:
            order.claimed_at,
        },

        newValue: {
          status:
            "pending",

          claimed_by:
            null,

          claimed_at:
            null,
        },

        reason:
          reason ||
          "Administrator manually released the withdrawal claim.",
      });

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "release",
        order:
          released.rows[0],
      });
    }

    /*
     * ========================================================
     * REASSIGN
     * ========================================================
     */
    if (action === "reassign") {
      if (!isAdmin(session)) {
        throw new Error(
          "Only an administrator can reassign a withdrawal."
        );
      }

      if (!assignedStaffId) {
        throw new Error(
          "Verification staff account not found."
        );
      }

      const staffResult =
        await client.query(
          `
            SELECT
              id,
              name,
              staff_login,
              role,
              enabled AS is_active,
              COALESCE(
                withdrawal_liquidity_enabled,
                TRUE
              ) AS withdrawal_liquidity_enabled
            FROM users
            WHERE id = $1
              AND role =
                'verification_staff'
            FOR UPDATE
          `,
          [assignedStaffId]
        );

      if (
        staffResult.rowCount !==
        1
      ) {
        throw new Error(
          "Verification staff account not found."
        );
      }

      const staff =
        staffResult.rows[0];

      if (!staff.is_active) {
        throw new Error(
          "Selected verification staff account is disabled."
        );
      }

      if (
        order.status !==
          "pending" &&
        order.status !==
          "processing"
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      /*
       * If an existing reservation belongs to another
       * staff member, release it first.
       */
      if (
        order.status ===
        "processing"
      ) {
        await releaseReservation(
          client,
          orderId,
          session.userId,
          "Administrator reassigned the withdrawal."
        );
      }

      /*
       * Reset to pending before allocating to the new
       * staff member.
       */
      await client.query(
        `
          UPDATE withdrawal_orders
          SET
            status = 'pending',
            claimed_by = NULL,
            claimed_at = NULL,
            claim_activity_at = NULL
          WHERE id = $1
        `,
        [orderId]
      );

      const refreshed =
        await client.query(
          `
            SELECT *
            FROM withdrawal_orders
            WHERE id = $1
            FOR UPDATE
          `,
          [orderId]
        );

      const reassignmentOrder =
        refreshed.rows[0];

      const allocation =
        await allocateWithdrawal(
          client,
          {
            order:
              reassignmentOrder,

            actorId:
              session.userId,

            requestedStaffId:
              assignedStaffId,

            automated:
              false,
          }
        );

      await audit(client, {
        actorId:
          session.userId,

        action:
          "withdrawal_reassign",

        entityId:
          orderId,

        previousValue: {
          status:
            order.status,

          claimed_by:
            order.claimed_by,
        },

        newValue: {
          status:
            "processing",

          claimed_by:
            assignedStaffId,

          reservation_id:
            allocation
              .reservation.id,

          reservation_amount:
            allocation
              .reservation.amount,
        },

        reason:
          reason ||
          "Administrator reassigned the withdrawal.",
      });

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "reassign",
        order:
          allocation.order,
        allocation: {
          staffId:
            allocation.staff.id,
          staffName:
            allocation.staff.name,
          reservedAmount:
            allocation
              .reservation
              .amount,
        },
      });
    }

    /*
     * ========================================================
     * PAYMENT / REJECTION
     * ========================================================
     */
    if (
      action === "pay" ||
      action === "reject"
    ) {
      if (isStaff(session)) {
        if (
          order.status !==
          "processing"
        ) {
          throw new Error(
            "Withdrawal is no longer processing."
          );
        }

        if (
          String(
            order.claimed_by
          ) !==
          String(
            session.userId
          )
        ) {
          throw new Error(
            "You are not assigned to this withdrawal."
          );
        }
      } else if (!isAdmin(session)) {
        throw new Error(
          "Only an administrator can perform this action."
        );
      }

      if (action === "pay") {
        if (!paymentReference) {
          throw new Error(
            "Payment reference is required."
          );
        }

        if (
          paymentReference.length >
          160
        ) {
          throw new Error(
            "Payment reference is too long."
          );
        }
      }

      if (action === "reject") {
        if (!reason) {
          throw new Error(
            "Rejection reason is required."
          );
        }

        if (reason.length > 500) {
          throw new Error(
            "Rejection reason is too long."
          );
        }
      }

      if (
        order.status !==
        "processing"
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      if (
        isStaff(session) &&
        String(
          order.claimed_by
        ) !==
          String(
            session.userId
          )
      ) {
        throw new Error(
          "You are not assigned to this withdrawal."
        );
      }

      /*
       * Lock the liquidity reservation.
       *
       * Every processing withdrawal created by the new
       * system must have one.
       */
      const reservationResult =
        await client.query(
          `
            SELECT
              id,
              staff_id,
              amount,
              status
            FROM withdrawal_liquidity_reservations
            WHERE withdrawal_order_id = $1
              AND status = 'reserved'
            FOR UPDATE
          `,
          [orderId]
        );

      /*
       * Legacy withdrawals may not have a reservation.
       * They are still allowed to finish so existing
       * production withdrawals are not stranded.
       */
      const reservation =
        reservationResult.rowCount
          ? reservationResult.rows[0]
          : null;

      /*
       * Lock matching withdrawal transaction.
       */
      const transactionResult =
        await client.query(
          `
            SELECT
              id,
              status,
              amount,
              fee
            FROM transactions
            WHERE reference = $1
              AND user_id = $2
            FOR UPDATE
          `,
          [
            `WD-${orderId}`,
            order.user_id,
          ]
        );

      if (
        transactionResult.rowCount !==
        1
      ) {
        throw new Error(
          "Matching withdrawal transaction not found."
        );
      }

      const transaction =
        transactionResult.rows[0];

      if (
        transaction.status !==
        "pending"
      ) {
        throw new Error(
          "Matching withdrawal transaction is not pending."
        );
      }

      /*
       * Lock customer wallet.
       */
      const walletResult =
        await client.query(
          `
            SELECT
              available_balance,
              reserved_balance
            FROM wallets
            WHERE user_id = $1
            FOR UPDATE
          `,
          [order.user_id]
        );

      if (!walletResult.rowCount) {
        throw new Error(
          "User wallet not found."
        );
      }

      const wallet =
        walletResult.rows[0];

      const availableBefore =
        Number(
          wallet.available_balance ||
            0
        );

      const reservedBefore =
        Number(
          wallet.reserved_balance ||
            0
        );

      const gross =
        Number(
          order.gross_amount ||
            0
        );

      if (
        !Number.isFinite(gross) ||
        gross <= 0
      ) {
        throw new Error(
          "Invalid withdrawal amount."
        );
      }

      if (
        reservedBefore <
        gross
      ) {
        throw new Error(
          "Reserved balance is insufficient for this withdrawal."
        );
      }

      /*
       * ======================================================
       * PAYMENT SENT
       * ======================================================
       */
      if (action === "pay") {
        const reservedAfter =
          reservedBefore -
          gross;

        const finalized =
          await client.query(
            `
              UPDATE withdrawal_orders
              SET
                status = 'paid',
                approved_by = $2,
                processed_at = NOW(),
                payment_reference = $3,
                payment_sent_at = NOW()
              WHERE id = $1
                AND status =
                  'processing'
                ${
                  isStaff(session)
                    ? "AND claimed_by = $2"
                    : ""
                }
              RETURNING *
            `,
            [
              orderId,
              session.userId,
              paymentReference,
            ]
          );

        if (
          finalized.rowCount !==
          1
        ) {
          throw new Error(
            "Withdrawal is no longer processing."
          );
        }

        await client.query(
          `
            UPDATE wallets
            SET
              reserved_balance = $1,
              updated_at = NOW()
            WHERE user_id = $2
          `,
          [
            reservedAfter,
            order.user_id,
          ]
        );

        const transactionUpdated =
          await client.query(
            `
              UPDATE transactions
              SET
                status =
                  'successful',
                updated_at =
                  NOW()
              WHERE id = $1
                AND reference = $2
                AND user_id = $3
                AND status = 'pending'
              RETURNING id
            `,
            [
              transaction.id,
              `WD-${orderId}`,
              order.user_id,
            ]
          );

        if (
          transactionUpdated.rowCount !==
          1
        ) {
          throw new Error(
            "Matching withdrawal transaction is not pending."
          );
        }

        await client.query(
          `
            INSERT INTO wallet_ledger (
              user_id,
              transaction_id,
              entry_type,
              amount,
              balance_after,
              description,
              created_at
            )
            VALUES (
              $1,
              $2,
              $3,
              $4,
              $5,
              $6,
              NOW()
            )
          `,
          [
            order.user_id,
            transaction.id,
            "withdrawal_approved",
            gross,
            availableBefore,
            "Withdrawal payment sent and reservation released.",
          ]
        );

        /*
         * Staff liquidity is consumed ONLY after payment
         * succeeds.
         */
        if (reservation) {
          await consumeReservation(
            client,
            orderId,
            session.userId
          );
        }

        await audit(client, {
          actorId:
            session.userId,

          action:
            "withdrawal_payment_sent",

          entityId:
            orderId,

          previousValue: {
            status:
              "processing",

            claimed_by:
              order.claimed_by,

            reserved_balance:
              reservedBefore,

            staff_liquidity_reservation:
              reservation
                ? {
                    id:
                      reservation.id,

                    staff_id:
                      reservation.staff_id,

                    amount:
                      reservation.amount,
                  }
                : null,
          },

          newValue: {
            status:
              "paid",

            approved_by:
              session.userId,

            payment_reference:
              paymentReference,

            payment_sent_at:
              finalized.rows[0]
                .payment_sent_at,

            reserved_balance:
              reservedAfter,

            staff_liquidity_consumed:
              reservation
                ? Number(
                    reservation.amount ||
                      0
                  )
                : 0,
          },
        });

        await client.query("COMMIT");

        return Response.json({
          success: true,
          action: "pay",
          order:
            finalized.rows[0],
        });
      }

      /*
       * ======================================================
       * REJECT + REFUND
       * ======================================================
       */
      const availableAfter =
        availableBefore +
        gross;

      const reservedAfter =
        reservedBefore -
        gross;

      const rejected =
        await client.query(
          `
            UPDATE withdrawal_orders
            SET
              status = 'rejected',
              approved_by = $2,
              processed_at = NOW(),
              rejection_reason = $3
            WHERE id = $1
              AND status =
                'processing'
              ${
                isStaff(session)
                  ? "AND claimed_by = $2"
                  : ""
              }
            RETURNING *
          `,
          [
            orderId,
            session.userId,
            reason,
          ]
        );

      if (
        rejected.rowCount !==
        1
      ) {
        throw new Error(
          "Withdrawal is no longer processing."
        );
      }

      await client.query(
        `
          UPDATE wallets
          SET
            available_balance = $1,
            reserved_balance = $2,
            updated_at = NOW()
          WHERE user_id = $3
        `,
        [
          availableAfter,
          reservedAfter,
          order.user_id,
        ]
      );

      const transactionUpdated =
        await client.query(
          `
            UPDATE transactions
            SET
              status = 'rejected',
              updated_at = NOW()
            WHERE id = $1
              AND reference = $2
              AND user_id = $3
              AND status = 'pending'
            RETURNING id
          `,
          [
            transaction.id,
            `WD-${orderId}`,
            order.user_id,
          ]
        );

      if (
        transactionUpdated.rowCount !==
        1
      ) {
        throw new Error(
          "Matching withdrawal transaction is not pending."
        );
      }

      await client.query(
        `
          INSERT INTO wallet_ledger (
            user_id,
            transaction_id,
            entry_type,
            amount,
            balance_after,
            description,
            created_at
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            NOW()
          )
        `,
        [
          order.user_id,
          transaction.id,
          "withdrawal_refund",
          gross,
          availableAfter,
          `Withdrawal rejected and ${gross} refunded to available balance. Reason: ${reason}`,
        ]
      );

      /*
       * Rejected withdrawal does NOT consume staff liquidity.
       * Release the reservation.
       */
      if (reservation) {
        await releaseReservation(
          client,
          orderId,
          session.userId,
          reason ||
            "Withdrawal rejected."
        );
      }

      await audit(client, {
        actorId:
          session.userId,

        action:
          "withdrawal_rejected",

        entityId:
          orderId,

        previousValue: {
          status:
            "processing",

          claimed_by:
            order.claimed_by,

          available_balance:
            availableBefore,

          reserved_balance:
            reservedBefore,

          staff_liquidity_reservation:
            reservation
              ? {
                  id:
                    reservation.id,

                  staff_id:
                    reservation.staff_id,

                  amount:
                    reservation.amount,
                }
              : null,
        },

        newValue: {
          status:
            "rejected",

          approved_by:
            session.userId,

          rejection_reason:
            reason,

          available_balance:
            availableAfter,

          reserved_balance:
            reservedAfter,

          staff_liquidity_released:
            reservation
              ? Number(
                  reservation.amount ||
                    0
                )
              : 0,
        },

        reason,
      });

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "reject",
        order:
          rejected.rows[0],
      });
    }

    /*
     * ========================================================
     * LEGACY ADMIN APPROVE
     * ========================================================
     *
     * Kept for compatibility with existing production data.
     *
     * New withdrawal-day processing should use:
     * allocate -> staff pay/reject
     */
    if (action === "approve") {
      if (!isAdmin(session)) {
        throw new Error(
          "Verification staff cannot approve withdrawals directly."
        );
      }

      if (
        order.status !==
          "pending" &&
        order.status !==
          "processing"
      ) {
        throw new Error(
          "Withdrawal is no longer pending."
        );
      }

      /*
       * If this withdrawal has a staff reservation,
       * consume it because Admin is finalizing the payment.
       */
      const reservation =
        await client.query(
          `
            SELECT
              id,
              staff_id,
              amount
            FROM withdrawal_liquidity_reservations
            WHERE withdrawal_order_id = $1
              AND status = 'reserved'
            FOR UPDATE
          `,
          [orderId]
        );

      const transactionResult =
        await client.query(
          `
            SELECT
              id,
              status
            FROM transactions
            WHERE reference = $1
              AND user_id = $2
            FOR UPDATE
          `,
          [
            `WD-${orderId}`,
            order.user_id,
          ]
        );

      if (
        transactionResult.rowCount !==
        1
      ) {
        throw new Error(
          "Matching withdrawal transaction not found."
        );
      }

      const transaction =
        transactionResult.rows[0];

      if (
        transaction.status !==
        "pending"
      ) {
        throw new Error(
          "Matching withdrawal transaction is not pending."
        );
      }

      const walletResult =
        await client.query(
          `
            SELECT
              available_balance,
              reserved_balance
            FROM wallets
            WHERE user_id = $1
            FOR UPDATE
          `,
          [order.user_id]
        );

      if (!walletResult.rowCount) {
        throw new Error(
          "User wallet not found."
        );
      }

      const availableBefore =
        Number(
          walletResult.rows[0]
            .available_balance ||
            0
        );

      const reservedBefore =
        Number(
          walletResult.rows[0]
            .reserved_balance ||
            0
        );

      const gross =
        Number(
          order.gross_amount ||
            0
        );

      if (
        !Number.isFinite(gross) ||
        gross <= 0
      ) {
        throw new Error(
          "Invalid withdrawal amount."
        );
      }

      if (
        reservedBefore <
        gross
      ) {
        throw new Error(
          "Reserved balance is insufficient for this withdrawal."
        );
      }

      const reservedAfter =
        reservedBefore -
        gross;

      const approved =
        await client.query(
          `
            UPDATE withdrawal_orders
            SET
              status = 'paid',
              approved_by = $2,
              processed_at = NOW()
            WHERE id = $1
              AND status IN (
                'pending',
                'processing'
              )
            RETURNING *
          `,
          [
            orderId,
            session.userId,
          ]
        );

      if (
        approved.rowCount !==
        1
      ) {
        throw new Error(
          "Withdrawal is no longer pending."
        );
      }

      await client.query(
        `
          UPDATE wallets
          SET
            reserved_balance = $1,
            updated_at = NOW()
          WHERE user_id = $2
        `,
        [
          reservedAfter,
          order.user_id,
        ]
      );

      const transactionUpdated =
        await client.query(
          `
            UPDATE transactions
            SET
              status =
                'successful',
              updated_at =
                NOW()
            WHERE id = $1
              AND reference = $2
              AND user_id = $3
              AND status = 'pending'
            RETURNING id
          `,
          [
            transaction.id,
            `WD-${orderId}`,
            order.user_id,
          ]
        );

      if (
        transactionUpdated.rowCount !==
        1
      ) {
        throw new Error(
          "Matching withdrawal transaction is not pending."
        );
      }

      await client.query(
        `
          INSERT INTO wallet_ledger (
            user_id,
            transaction_id,
            entry_type,
            amount,
            balance_after,
            description,
            created_at
          )
          VALUES (
            $1,
            $2,
            $3,
            $4,
            $5,
            $6,
            NOW()
          )
        `,
        [
          order.user_id,
          transaction.id,
          "withdrawal_approved",
          gross,
          availableBefore,
          "Administrator approved withdrawal.",
        ]
      );

      if (
        reservation.rowCount
      ) {
        await consumeReservation(
          client,
          orderId,
          session.userId
        );
      }

      await audit(client, {
        actorId:
          session.userId,

        action:
          "withdrawal_admin_approve",

        entityId:
          orderId,

        previousValue: {
          status:
            order.status,

          claimed_by:
            order.claimed_by,

          reserved_balance:
            reservedBefore,
        },

        newValue: {
          status:
            "paid",

          approved_by:
            session.userId,

          reserved_balance:
            reservedAfter,
        },
      });

      await client.query("COMMIT");

      return Response.json({
        success: true,
        action: "approve",
        order:
          approved.rows[0],
      });
    }

    throw new Error(
      "Invalid withdrawal action."
    );
  } catch (error) {
    try {
      await client.query("ROLLBACK");
    } catch {}

    console.error(
      "POST /api/admin/withdrawals failed:",
      error
    );

    return Response.json(
      {
        error:
          safeError(error),
      },
      {
        status: 400,
      }
    );
  } finally {
    client.release();
  }
}
